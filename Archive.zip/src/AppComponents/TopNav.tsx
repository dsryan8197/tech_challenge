//imports
import React from 'react';

//Header
const TopNav: React.FC = () => {
  return (
    <div className='top-nav-container'>
      <h1 className="welcome">Welcome to IHeartRadio</h1>
    </div>
  );
}

export default TopNav;


