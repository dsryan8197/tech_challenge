//imports
import React from 'react';

//about me page
const Seamus: React.FC = () => {
  return (
    <div className='seamusDiv'>
        <p>Thank you for reviewing my take-home assessment. I would love to schedule a chat to talk about how I would refactor this and some of the unexpected challenges I faced in development. Mainly dealing with the wild Webpack 5.0 Updates with TypeScript </p>
          <p>Fun facts about me: </p> 
          <p>I </p>
          <p>I ran with the bulls in Pamplona, Spain</p>
          <p></p>
    </div>
  );
}

export default Seamus;


